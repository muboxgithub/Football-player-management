const express = require('express'); // Import Express.js
const db = require('./connection'); // Import database connection module
const cors = require('cors'); // Import CORS for handling cross-origin requests
const path = require('path'); // Import path module for handling file paths
const bodyparser = require('body-parser'); // Import body-parser for parsing request bodies
const multer = require('multer'); // Import Multer for handling file uploads

const port = 5000; // Define the port number
const app = express(); // Create an Express application

// Middleware setup
app.use(cors()); // Enable CORS
app.use(bodyparser.json()); // Parse JSON request bodies
app.use(bodyparser.urlencoded({ extended: true })); // Parse URL-encoded request bodies

// Configure Multer storage
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, path.join(__dirname, 'upload')); // Set the upload directory
    },
    filename: (req, file, cb) => {
        cb(null, file.originalname); // Use the original file name
    }
});

const upload = multer({ storage }); // Initialize Multer with the storage configuration

// Define a POST route for file upload
app.post('/app/upload', upload.single('image'), (req, res) => {
    const { fullname, team, award, comment } = req.body; // Extract fields from request body
    const image = req.file ? req.file.filename : null; // Get the uploaded file name

    const query = "INSERT INTO `player` (`full_name`, `team`, `award`, `comment`, `image`) VALUES (?, ?, ?, ?, ?)"; // Define SQL query

    db.query(query, [fullname, team, award, comment, image], (err, result) => {
        if (err) {
            console.error('Error occurred during inserting player data'); // Log error
            res.status(500).json({ error: 'Error occurred during inserting' }); // Respond with error
            return;
        }
        res.status(200).json({ message: 'Data inserted successfully' }); // Respond with success message
    });
});

// Start the server
app.listen(port, () => {
    console.log(`Server started successfully http://localhost:${port}`);
});
